

import { ThrowStmt } from '@angular/compiler';
import { Component, HostListener, HostBinding, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {AppDetailService} from './app-detail.service'


export enum KeyCodes {
  LEFT = 37,
  RIGHT = 39
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  counter: number = 0;
  title = 'moving-box-app';
  classBorder: string = '';
  public noofboxes:any;
  isKey=true;
  boxselected:any;
  constructor(private _route: ActivatedRoute,private appdetailservice:AppDetailService) {
   // this.fragment = _route.snapshot.fragment;
  }
  ngOnInit(){
    this.noofboxes=[];
    this.appdetailservice.getSourceMetaData().subscribe((data:any)=> {
this.appdetailservice.boxdata=data;
this.noofboxes=this.appdetailservice.boxdata;

    })
  }

  @HostListener('document:keyup', ['$event'])
  KeyUpEvent(event: KeyboardEvent) {
    if(!this.isKey){
      event.stopPropagation();
    }
 
  console.log(event);
    if (event.keyCode == KeyCodes.LEFT)
      this.counter--;
    if (event.keyCode == KeyCodes.RIGHT)
      this.counter++;
  }

     addBoxes(totaldata:any){
       var newbox={
         id:totaldata.length,name:"Box"+ (totaldata.length+1).toString()
       }
      totaldata.push(newbox);
      this.appdetailservice.boxdata=totaldata;
      this.noofboxes=this.appdetailservice.boxdata;
     }
     getclickedboxdata(event:any){
    console.log(event)
    var arrayofid:any=[]
    this.noofboxes.forEach((element:any) => {
      arrayofid.push(element.id);
    });
    let idx = this.noofboxes.findIndex((el:any) => {
      return event.item.id === el.id;
    });
    console.log(idx);  
    this.boxselected=event.item.id;
    if(event.event.key ==='ArrowRight'){
      const tmp = this.noofboxes[idx]
      this.noofboxes[idx] = this.noofboxes[(idx+1)]
      this.noofboxes[(idx+1)] = tmp
      console.log(this.noofboxes);  
    }
    else if(event.event.key ==='ArrowLeft'){
      const tmp = this.noofboxes[idx]
      this.noofboxes[idx] = this.noofboxes[(idx-1)]
      this.noofboxes[(idx-1)] = tmp
      console.log(this.noofboxes); 
    }
    else if(event.event.key ==='ArrowUp'){
      const tmp = this.noofboxes[idx]
      this.noofboxes[idx] = this.noofboxes[(idx-6)]
      this.noofboxes[(idx-6)] = tmp
      console.log(this.noofboxes); 
    }
    else if(event.event.key ==='ArrowDown'){
      const tmp = this.noofboxes[idx]
      this.noofboxes[idx] = this.noofboxes[(idx+6)]
      this.noofboxes[(idx+6)] = tmp
      console.log(this.noofboxes); 
    }
    else if(event.event.key ==='Delete'){
      console.log(idx); 
      // delete  this.noofboxes[idx];
      this.noofboxes.splice(idx,1);
      console.log(this.noofboxes); 
    }
 
     }
     toggle(event:any,isKey:boolean){
       this.isKey=!this.isKey;
console.log(this.isKey);
     }
}



