import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { HttpClient ,HttpErrorResponse,HttpEventType } from '@angular/common/http';
import { map, flatMap,switchMap, shareReplay, distinctUntilChanged, tap, share,catchError } from 'rxjs/operators';
import { BehaviorSubject, timer, Observable,throwError,of, pipe } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppDetailService {
public boxdata=[];
  constructor(private http: HttpClient) { }
  getSourceMetaData(): Observable<any> {
    
    return this.http.get<any>(`${environment.sourceMetaDataUrl}`);
  }
}
