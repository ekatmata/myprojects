import { TestBed } from '@angular/core/testing';

import { AppDetailService } from './app-detail.service';

describe('AppDetailService', () => {
  let service: AppDetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppDetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
