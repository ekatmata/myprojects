import { Component, OnInit,Input ,Output,EventEmitter,HostListener,Renderer2,ElementRef,HostBinding, OnChanges} from '@angular/core';

@Component({
  selector: 'app-card-box',
  templateUrl: './card-box.component.html',
  styleUrls: ['./card-box.component.scss']
})
export class CardBoxComponent implements OnChanges{
@Input() public boxdata:any;
@Input() public slectedbox:any;
selectedIndex:any;

@Output() public keyeventemmiter = new EventEmitter();
  constructor(private renderer: Renderer2) { }
  clickeditem:any;
  slecteditem:any;
  @HostListener('document:keyup', ['$event'])
  KeyUpEvent(event: KeyboardEvent) {
  console.log(event);
   this.getClickedBox(event,this.clickeditem,this.slecteditem)
  }


  // KeyUpEvent(event: KeyboardEvent) {
  // console.log(event);
  // }
  ngOnChanges(): void {
    this.slecteditem=this.slectedbox;
    console.log(this.slectedbox);
   
  }
 

  getClickedBox(event:any,items:any,index:any){
    this.clickeditem=items;
    console.log(event);
    console.log(items.id);
    console.log(index);
    this.slecteditem=index;
   

    if(event.type!=='click'){
    this.keyeventemmiter.emit({
      event:event,
      item:items,
      index:this.selectedIndex
      });
    }
 
      }

}
